"""
dyca.

Dynamical Component Analysis - A method to decompose multivariate signals
"""

__version__ = '0.1.0'
__author__ = 'Annika Stiehl'
__credits__ = 'University of Applied Sciences Ansbach'
__license__ = 'GPL-3.0'
